


CSYE 6225 FALL-2017 
ASSIGNMENT 4

To Execute
	
	To create ec2 instance
		./launch-ec2-instance.sh
	To terminate ec2 instance
		./terminate-ec2-instance.sh

		
