


CSYE 6225 FALL-2017 
ASSIGNMENT 4

To Execute
	
	To create stack
		./create-csye6225-cloudformation-stack..sh
	To delete stack
		./delete-csye6225-cloudformation-stack.sh

		
