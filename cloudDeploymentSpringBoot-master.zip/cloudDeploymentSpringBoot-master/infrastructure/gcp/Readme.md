gcloud compute instances create [EXAMPLE_INSTANCE] --image [IMAGE_NAME]
