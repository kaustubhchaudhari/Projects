


CSYE 6225 FALL-2017 
ASSIGNMENT 3

TEAM
Akhila Kunche : kunche.a@husky.neu.edu 
Akshay Nakhawa : nakhawa.a@husky.neu.edu 
Kaustubh Chaudhari : chaudhari.k@husky.neu.edu 
Prachi Saxena : saxena.pr@husky.neu.edu

Instructions to run
Move to the directory and execute the following commands
  - CLOUD FORMATION
    - ./create-csye6225-cloudformation-stack.sh
    - ./delete-csye6225-cloudformation-stack.sh
  - SCRIPTS
    - ./launch-ec2-instance.sh
    - ./terminate-ec2-instance.sh
