#!/bin/bash

sudo systemctl restart tomcat8
sudo systemctl restart awslogs.service
