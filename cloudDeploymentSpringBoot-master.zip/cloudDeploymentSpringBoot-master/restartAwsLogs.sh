#!/bin/bash

sudo systemctl restart awslogs.service
